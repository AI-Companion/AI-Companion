simple nginx/react/gunicorn/flask webapp boilerplate/whatever 

frontend is a docker container serving static single-page reactjs app with
nginx

backend is also a docker container serving flask-based api with gunicorn.

Database is sqlite. Get over it.
