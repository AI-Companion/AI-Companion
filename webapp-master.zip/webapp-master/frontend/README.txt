==static webapp
See https://docs.docker.com/samples/library/nginx/#hosting-some-simple-static-content

This is a basic base for running nginx. to build the image, run 
    
    bash build.sh

To run it, run

    bash run.sh

Then go to localhost:8000 to see the app.

See the Dockerfile for how to build it locally... outside docker
